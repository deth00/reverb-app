<?php

namespace App\Livewire\Backend\Score;

use Livewire\Component;
use App\Models\Subject;
use App\Models\Registed;
use Livewire\Attributes\On;
use App\Events\SendRealtimeMessage;
use Illuminate\Database\Eloquent\Builder;
use Jantinnerezo\LivewireAlert\LivewireAlert;
use Illuminate\Support\Facades\DB;

class ViewScoreComponent extends Component
{
    use LivewireAlert;
    public string $message;
    public $data, $datas, $count, $edit_id;
    public $subject, $subject_id, $user_id, $search;
    public $score = [], $vote = [], $vote_count, $del_count;

    public function mount($id){
        $this->subject = Subject::find($id);
        $this->subject_id = $id;
        $this->message = $id;
        $this->user_id = auth()->user()->id;
        $this->data = Registed::where('subject_id',$this->subject_id)->get();
        $this->count = count(Registed::where('subject_id',$this->subject_id)->get());

        if($this->subject['user_id'] == auth()->user()->id){
            if($this->subject['registed'] != $this->count){
                session()->flash('error', 'ຜູ້ສະໝັກບໍ່ຕົງກັບທີ່ກຳນົດ');
                return redirect(route('registeds',$this->subject_id));
            }
        }else{
            session()->flash('error', 'ລາຍການນີ້ຍັງບໍ່ເປີດການລົງຄະແນນ');
            return redirect(route('dashboard'));
        }
        
    }

    public function triggerEvent(): void
    {
        event(new SendRealtimeMessage($this->message));
    }

    #[On('echo:my-channel,SendRealtimeMessage')]
    public function handleRealtimeMessage($message): void 
    {
        $this->datas = Registed::where('subject_id',$message['message'])->orderBy('no', 'asc')->get();
    }



    public function render()
    {
        if($this->score != []){
            $this->vote = Registed::where('subject_id',$this->subject_id)->whereIn('no',$this->score)->get();
            // dd($this->vote);
        }

        $this->datas = Registed::where('subject_id',$this->subject_id)->orderBy('no', 'asc')->get();
        $datas_count = Subject::where('id',$this->subject_id)->first();
        $sum_count = Registed::where('subject_id',$this->subject_id)->orderBy('no', 'asc')->sum('score');
        return view('livewire.backend.score.view-score-component',compact('datas_count','sum_count'));
    }

    public function add($ids){
        $sum_count = Registed::where('subject_id',$this->subject_id)->orderBy('no', 'asc')->sum('score');
        $result = $sum_count / $this->subject['selected'];

        if($result < $this->subject['total']){
            $score = Registed::find($ids);
            if($score->score < $this->subject['total']){
                $score->score += 1;
                $score->save();
            }else{
                $this->dispatch('alert',type: 'error', message:'ບໍ່ສາມາດເພີ່ມໄດ້ຈຳນວນຄະແນນເລືອກຕັ້ງສູງສຸດແລ້ວ!');
            }
        }else{
            $this->dispatch('alert',type: 'error', message:'ບໍ່ສາມາດເພີ່ມໄດ້ຈຳນວນຄະແນນເລືອກຕັ້ງສູງສຸດແລ້ວ!');
        }
        
    }

    public function del($ids){
        $score = Registed::find($ids);
        if($score->score  > 0){
            $score->score -= 1;
            $score->save();
        }else{
            $this->dispatch('alert',type: 'error', message:'ບໍ່ສາມາດລົບໄດ້ຈຳນວນຄະແນນເລືອກຕັ້ງຕ່ຳສຸດແລ້ວ!');
        }
        
    }
    public int $expire;
    public function finish(){
        $sum_count = Registed::where('subject_id',$this->subject_id)->orderBy('no', 'asc')->sum('score');
        $result = $sum_count / $this->subject['selected'];
        $this->expire =(int) $this->subject['total'] - (int) $result;
        // dd($this->expire);
        $subject = Subject::find($this->subject_id);
        $subject->expire = $this->expire;
        $subject->status = 1;
        $subject->save();
        session()->flash('success', 'ສິ້ນສຸດການລົງຄະແນນ');
        return redirect(route('dashboards'));
    }

    public function showVote(){
        if($this->score != []){
            $this->vote = Registed::where('subject_id',$this->subject_id)->whereIn('no',$this->score)->get();
            $this->vote_count = 'disabled';
            $this->dispatch('show-select');
        }else{
            $this->dispatch('alert',type: 'warning', message:'ກະລຸນາປ້ອນຂໍ້ມູນຜູ້ຖືກເລືອກໃຫ້ຄົບ!');
        }
     }

     public function clear(){
        $this->score = [];
        $this->vote = [];
        $this->vote_count = null;
        $this->dispatch('show-reset');
     }

     public function showDel(){
        if($this->score != []){
            $this->vote = Registed::where('subject_id',$this->subject_id)->whereIn('no',$this->score)->get();
            $this->del_count = count(Registed::where('subject_id',$this->subject_id)->whereIn('no',$this->score)->get());
        }else{
            $this->dispatch('alert',type: 'warning', message:'ກະລຸນາປ້ອນຂໍ້ມູນຜູ້ຖືກເລືອກໃຫ້ຄົບ!');
        }
     }

    public function store(){
        try {
            $subject = Subject::find($this->subject_id);
            if(count($this->score) == $subject->selected){
                    foreach($this->score as $item){
                        $add = Registed::where('subject_id',$this->subject_id)->where('no',$item)->first();
                        $add->score += 1;
                        $add->save();

                    }
                    $this->score = [];
                    $this->dispatch('alert',type: 'success', message:'ເພີ່ມສຳເລັດ!');
                    $this->clear();
                    $this->vote_count = null;
                    $this->dispatch('show-reset');
                // }
            }else{
                $this->dispatch('alert',type: 'warning', message:'ກະລຸນາປ້ອນຂໍ້ມູນຜູ້ຖືກເລືອກໃຫ້ຄົບ!');
            }
        } catch (\Throwable $th) {
            DB::rollBack();
            $this->dispatch('alert',type: 'error', message:'ເກີດຂໍ້ຜິດພາດກະລຸນາລອງໃໝ່!');
        }
        
    }

    public function rm(){
        try {
            $subject = Subject::find($this->subject_id);
            if(count($this->score) == $subject->selected){
                    foreach($this->score as $item){
                        if($item != 0){
                            $add = Registed::where('subject_id',$this->subject_id)->where('no',$item)->first();
                            $add->score -= 1;
                            $add->save();
                        }
                    }
                    $this->score = [];
                    $this->dispatch('alert',type: 'success', message:'ເພີ່ມສຳເລັດ!');
                    $this->clear();
                    $this->del_count = null;
            }else{
                $this->dispatch('alert',type: 'warning', message:'ກະລຸນາປ້ອນຂໍ້ມູນຜູ້ຖືກເລືອກໃຫ້ຄົບ!');
            }
        } catch (\Throwable $th) {
            DB::rollBack();
            $this->dispatch('alert',type: 'error', message:'ເກີດຂໍ້ຜິດພາດກະລຸນາລອງໃໝ່!');
        }
        
    }
}
