                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12 text-left">
                                2023 - 2024 &copy; ພັດທະນາໂດຍ: <a href="javascript:void(0)">ພະແນກເຕັກໂນໂລຊີຂໍ້ມູນຂ່າວສານ</a> ລະບົບນັບຄະແນນ 2024 ເວີຊັ່ນ: 1.0.1
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->