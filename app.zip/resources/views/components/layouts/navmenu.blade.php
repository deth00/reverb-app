<div class="topbar-menu">
    <div class="container-fluid">
        <div id="navigation">
            <!-- Navigation Menu-->
            <ul class="navigation-menu">

                <li>
                    <a href="{{route('dashboards')}}" class="phetsarath-font"> <i class="mdi mdi-view-dashboard"></i>ໜ້າຫຼັກ</a>
                </li>

                <li>
                    <a href="{{route('subjects')}}" class="phetsarath-font"> <i class="mdi mdi-pencil-box-multiple"></i>ຫົວຂໍ້ການນັບຄະແນນ</a>
                </li>
         
                <!-- <li class="has-submenu">
                    <a href="#"> <i class="mdi mdi-file-document-box-multiple-outline"></i> ລາຍງານການເລືອກຕັ້ງຜ່ານມາ
                    </a>
                    <ul class="submenu">
                        <li><a href="#">....</a></li>
                    </ul>
                </li> -->


            </ul>
            <!-- End navigation menu -->

            <div class="clearfix"></div>
        </div>
        <!-- end #navigation -->
    </div>
    <!-- end container -->
</div>
<!-- end navbar-custom -->