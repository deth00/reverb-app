<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="{{asset('backend/assets/css/style.css')}}" rel="stylesheet" type="text/css" id="style-stylesheet">
</head>
<body>
    <h1 class="phetsarath-font" style="font-family: 'Phetsarath OT';">ສະບາຍດີ</h1>
    <h4 class="phetsarath-font">{{$k}}</h4>
</body>
</html>